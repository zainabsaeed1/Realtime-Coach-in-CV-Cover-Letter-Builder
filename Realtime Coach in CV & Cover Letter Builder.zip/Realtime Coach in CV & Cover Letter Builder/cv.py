from flask import Flask, render_template, request, jsonify
from groq import Groq
import os

app = Flask(__name__)
groq_api_key = "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"  # Replace with your Groq API key
client = Groq(api_key=groq_api_key)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/analyze', methods=['POST'])
def analyze():
    text = request.json.get("text", "")
    role = request.json.get("role", "general")

    prompt = f"""You are a professional CV coach. Analyze the following CV bullet point for tone, structure, clarity, and redundancy. Also:
- Suggest a better rephrased bullet using STAR method if needed.
- Highlight if this line is too similar to previous input.
- Match the writing style with the role: {role}.
- Format the output as scannable bullet.

Input:
{text}

Respond in JSON like this:
{{
    "feedback": "Clear and action-driven tone, but a bit redundant.",
    "suggestion": "Led weekly syncs across departments, boosting delivery speed by 30%.",
    "formatted": "• Led cross-functional syncs; improved turnaround time by 30%"
}}"""

    try:
        chat_response = client.chat.completions.create(
            model="llama3-8b-8192",
            messages=[
                {"role": "system", "content": "You are an expert CV-writing assistant."},
                {"role": "user", "content": prompt}
            ]
        )
        ai_text = chat_response.choices[0].message.content.strip()

        # Try parsing clean JSON from LLM
        import json, re
        json_str = re.search(r'{.*}', ai_text, re.DOTALL)
        parsed = json.loads(json_str.group()) if json_str else {
            "feedback": "AI could not parse response.",
            "suggestion": "",
            "formatted": ""
        }

        return jsonify(parsed)

    except Exception as e:
        return jsonify({"feedback": "Error processing request.", "suggestion": "", "formatted": "", "error": str(e)})

if __name__ == "__main__":
    app.run(debug=True)
